package com.ssms.stock.master.service.impl;

import org.springframework.stereotype.Service;

import com.ssms.stock.master.service.intf.StockMasterService;

@Service
public class StockMasterServiceImpl implements StockMasterService{

}
