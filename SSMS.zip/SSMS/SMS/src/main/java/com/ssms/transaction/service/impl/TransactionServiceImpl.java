package com.ssms.transaction.service.impl;

import org.springframework.stereotype.Service;

import com.ssms.transaction.service.intf.TransactionService;

@Service
public class TransactionServiceImpl implements TransactionService {

}
