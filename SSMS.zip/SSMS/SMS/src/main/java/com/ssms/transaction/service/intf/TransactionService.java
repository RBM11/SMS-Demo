package com.ssms.transaction.service.intf;

public interface TransactionService {

}
