package com.ssms.transaction.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class TransactionManagementController {

}
