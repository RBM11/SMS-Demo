package com.ssms.constants;

/**
 * The Class StringContants.
 */
public final class StringContants {

	/** The Constant SUCCESS. */
	public static final String  SUCCESS = "success";
	
	/**
	 * Instantiates a new string contants.
	 */
	private StringContants() {
		throw new IllegalArgumentException("StringContants");
	}
}
