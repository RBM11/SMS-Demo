package com.ssms.stock.master.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class StockMasterController {

}
