package com.ssms.transaction.dao.impl;

import org.springframework.stereotype.Repository;

import com.ssms.transaction.dao.intf.TransactionsDao;

@Repository
public class TransactionsDaoImpl implements TransactionsDao {

}
