package com.ssms.stock.master.dao.impl;

import org.springframework.stereotype.Repository;

import com.ssms.stock.master.dao.intf.StockMasterDao;

@Repository
public class StockMasterDaoImpl implements StockMasterDao{

}
