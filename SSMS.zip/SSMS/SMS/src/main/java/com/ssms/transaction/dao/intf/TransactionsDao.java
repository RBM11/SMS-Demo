package com.ssms.transaction.dao.intf;

public interface TransactionsDao {

}
