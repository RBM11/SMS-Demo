package com.ssms.stock.master.dao.intf;

public interface StockMasterDao {

}
