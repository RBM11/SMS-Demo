package com.ssms.stock.master.service.intf;

public interface StockMasterService {

}
